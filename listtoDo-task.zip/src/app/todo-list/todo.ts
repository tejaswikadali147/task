export class TodoList {
  id: number;
  todo: string;
  date: Date;
}